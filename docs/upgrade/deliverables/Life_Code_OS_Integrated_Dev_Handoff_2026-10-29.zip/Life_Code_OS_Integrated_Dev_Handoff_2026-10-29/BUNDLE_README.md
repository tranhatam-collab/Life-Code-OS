# Life Code OS — Planning and DEV handoff bundle 2026-10-29

This is the complete local planning/document bundle, including original sources,
the immutable local r2 plan, the new integrated plan, artifact QA and helpers.
It is not a checkout of application code and does not authorize deployment.

Start at docs/upgrade/2026-10-29/START_HERE.md or the Word/PDF/Excel exports.
From this extracted root, verify without executing attached importers or SQL:

    python3 -B tools/planning/oct29/verify_final.py --portable

Application development must use the exact reviewed repository candidate and
accepted work order. Source ZIPs, historical receipts and absolute paths inside
receipts retain their original identity; they are not the current runtime.

BUNDLE_MANIFEST.json excludes itself. The external delivery receipt records the
ZIP hash and the manifest hash, preventing receipt/manifest self-reference cycles.
