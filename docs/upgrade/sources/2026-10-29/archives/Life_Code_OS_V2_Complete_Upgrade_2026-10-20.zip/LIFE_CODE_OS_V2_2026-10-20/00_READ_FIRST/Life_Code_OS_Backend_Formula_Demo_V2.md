# BACKEND, CÔNG THỨC & DEMO

# Backend V2: ranh giới mô-đun, đường dữ liệu và bảo đảm tính đúng

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Từ yêu cầu tới báo cáo
Gateway xác thực → resolve subject và grant → kiểm tra purpose/entitlement → khóa profile version → chọn method releases → validate inputs → lập DAG → chạy công cụ → kiểm tra kết quả → tạo claims → tổng hợp → viết nội dung → review → phát hành snapshot. Mỗi bước ghi state transition và trace ID nhưng không ghi nguyên payload nhạy cảm vào log.

Modular monolith được chia miền identity, profiles, knowledge, methods, observations, synthesis, reports, commerce, practice và operations. Mỗi miền có service boundary và data ownership. Không có domain nào được trực tiếp bỏ qua authorization bằng cách truy vấn bảng của domain khác. API layer không chứa công thức; renderer không tính lại.

## 2. Hai API khác nhau phải được ghi đúng
`06_DEMO_LAB` chỉ có local HTTP API không xác thực, bind loopback và dùng dữ liệu tổng hợp. `openapi.target.v2.json` là hợp đồng sản phẩm đích với cookie/session và quyền, chưa được triển khai. Demo không nhận cookie production, không dùng database và không được deploy như API công khai. Mọi tệp và màn hình ghi `REFERENCE_ONLY` để tránh nhập nhằng.

## 3. Khóa phiên bản đầu vào
Run dùng profile_version_id, hypothesis_selection, product_release_id, method_release_ids, purpose_id, access_revision và input_digest. Dữ liệu không được lấy lại từ profile live giữa lúc run đang xử lý. Một người sửa ngày sinh trong khi đang render không làm bản đang dựng đổi một nửa; tạo run mới với snapshot mới.

## 4. Tính đồng bộ và bất đồng bộ
Phép số nguyên ngắn có thể trả đồng bộ. Pipeline nhiều phương pháp hoặc export trả 202 cùng run_id, state và polling/SSE endpoint. Worker xử lý công việc phải kiểm tra lại grant, purpose, quyền phương pháp và trạng thái deletion trước khi đọc input và trước khi publish. Việc queue đã nhận không là bảo đảm được quyền hoàn tất.

## 5. Thiết kế lỗi
Lỗi dùng Problem Details với code ổn định, trace ID và thông báo tiếng Việt dễ hiểu. Phân biệt validation, thiếu phương pháp, thiếu đầu vào, conflict, rate limit và lỗi hạ tầng. Không trả stack trace hoặc câu SQL. Retry chỉ cho lỗi tạm thời, không retry lỗi quyền, dữ liệu hoặc phương pháp chưa phát hành. [N05]

## 6. Tái lập kết quả
Cùng input đã chuẩn hóa, cấu hình, bảng nguồn và dependency version phải trả cùng calculation. Ngày hiện tại phải truyền như tham số as_of chứ không ẩn trong engine. Random chỉ được dùng nếu một phương pháp quy định sự gieo ngẫu nhiên, và phải lưu phương thức cùng dữ kiện tương ứng; tuyệt đối không dùng random để tạo năm rủi ro.

Hash cần bind vào cả input, method version, table/source digest và cấu hình. Dữ liệu cá nhân entropy thấp không được công khai bằng hash trần vì có thể đoán lại; production cần HMAC tenant-scoped hoặc cơ chế tương đương do security duyệt. Demo dùng SHA-256 để tái lập, không gọi đó là ẩn danh hóa. [N06]

**Tra nguồn:** xem `11_SOURCES/SOURCE_ADDENDUM.csv`; các mã Nxx là nguồn đối chiếu chính thức, không phải mọi nhận định của HNH đã được khoa học xác nhận.


# Công thức, ma trận và chính sách sai số

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Mỗi công thức có một hợp đồng
Catalog `FORMULA_CATALOG.json` tách trường input, miền hỗ trợ, đơn vị, cấu hình, công thức, output, dữ liệu thiếu, lỗi, độ phức tạp, code path, demo IDs và trạng thái. Mã LCF-01 đến LCF-16 là họ phép tính tham chiếu có implementation, không phải 16 bộ môn đã được chứng minh khoa học. Những công thức nâng cao được ghi `SPEC_ONLY` hoặc `RESEARCH_ONLY`.

## 2. Mã đuôi 80
N là chuỗi đúng bốn chữ số; r=N mod 80. Số dư 0 mặc định unresolved; ánh xạ 0→80 chỉ khi cấu hình as80 được duyệt. Giữ số 0 đầu. Không dùng số thực rồi cắt phần lẻ. Bảng nhãn là một artifact có version; thiếu nguyên văn không được tự tạo nguyên văn. 10.000 đuôi chia đều 125/mã khi bật as80. Không cá nhân hóa từ phép tính không nhận hồ sơ.

## 3. Chuỗi cặp và ma trận chữ số
Với dãy n chữ số, tạo n−1 cặp chồng lấn. Bảng 64 dùng tập {1, 2, 3, 4, 6, 7, 8, 9}; cặp chứa 0 hoặc 5 ở policy strict trả unresolved. Policy bridge5_diagnostic là phân tích độ nhạy công khai, không được âm thầm áp hoặc coi là nguồn truyền thống đã phê duyệt. Ma trận thô đếm chữ số gốc; việc không có số 9 không nói trí nhớ kém. Các đường tổng chỉ là tổng số lần xuất hiện trong các ô được quy định.

## 4. Tên và rút gọn
Tên gốc → NFC → chuỗi VI-Latin theo quy tắc minh bạch. Đ được đổi thành D ở derivative. A–Z quy đổi tuần hoàn 1–9. Tổng nguyên âm/phụ âm có chính sách Y include/exclude; không có mặc định phổ quát cho mọi ngôn ngữ. Văn tự chưa hỗ trợ được từ chối, không tự Latin hóa rồi luận như cùng phương pháp. [N07]

Rút gọn giữ trace: 38→11→2 hoặc dừng ở 11 tùy policy. Cách cộng toàn bộ chữ số và cách rút gọn thành phần được lưu riêng. Căn đơn bằng 0 nếu n=0, bằng 1+((n−1) mod 9) nếu n>0. Mọi số phải là safe integer trong demo; tiền không đi qua floating-point.

## 5. Hào và quẻ
Demo nhận sáu bit từ dưới lên, 0 âm,1 dương. Hào động là tập chỉ số 1–6 không trùng. Quẻ biến lật đúng bit; chỉ số nhị phân không phải số thứ tự Văn Vương. Kiểm thử toàn bộ 64 quẻ × 64 mặt nạ. Không gán tên/lời quẻ trước khi khóa bảng ánh xạ, nguồn và quyền. Đây là ví dụ dùng toán học để làm rõ cấu trúc, không biến biểu tượng thành chứng minh đời người.

## 6. Điểm ưu tiên có trọng số
MCDA chỉ dùng tiêu chí và trọng số người dùng hiểu, tổng trọng số 100. Khi thiếu một tiêu chí, giữ nguyên mẫu số, hiển thị coverage và chặn xếp hạng toàn bộ; không renormalize âm thầm làm phương án thiếu dữ liệu có vẻ tốt hơn. Điểm là ưu tiên theo tiêu chí, không phải “độ hợp mệnh”.

## 7. Công thức từ dữ liệu thực
Action completion = số việc done đến hạn trong cửa sổ / số việc không hủy đến hạn trong cửa sổ. Mẫu số 0 trả null. Dòng tiền = tổng inflow−outflow theo từng currency, dùng minor units dạng chuỗi nguyên; không cộng VND với USD. Resonance chỉ tổng hợp điểm tự khai theo field/date; mean không chứng minh quan hệ nhân quả hoặc hiệu quả điều trị.

**Tra nguồn:** xem `11_SOURCES/SOURCE_ADDENDUM.csv`; các mã Nxx là nguồn đối chiếu chính thức, không phải mọi nhận định của HNH đã được khoa học xác nhận.


# Lịch, giờ sinh, múi giờ và nhiều giả thuyết

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Dữ liệu thời gian phải có nguồn
BirthRecord giữ calendar, date_original, date_iso khi quy đổi được, precision, local_time, time_range, place_original, timezone_id, coordinates và source. Không suy múi giờ từ vị trí hiện tại. Geocoding là bước gợi ý có người xác nhận, không lấy tên tỉnh cùng tên ở nơi khác làm kết quả chắc chắn. IANA tzdb được lưu version. [N08]

## 2. Các trường hợp khó phải là ca chuẩn
Chỉ biết năm → không điền 01/01. Không rõ giờ → không điền 00:00. Giờ được nhớ “khoảng 6–7 giờ” → khoảng, không một timestamp. Ngày dương/âm chưa rõ → yêu cầu xác nhận calendar. Nơi sinh chưa biết → không chạy phương pháp cần tọa độ chính xác. Ngày 29/02 → chọn chính sách anniversary theo sản phẩm và ghi rõ.

## 3. DST fold và gap
Một local time có thể ứng với 0, 1 hoặc 2 thời điểm UTC. Demo dùng Intl/ICU, liệt kê offset ứng viên trong vùng thời gian và đối chiếu lại phần local, không âm thầm chọn một. Gap yêu cầu sửa nguồn; fold yêu cầu lựa chọn hoặc chạy hai phương án. Phạm vi demo 1900–2100, sampling offset không thay một thư viện thiên văn/lịch pháp được thẩm định cho mọi thời kỳ.

## 4. Giờ Mặt Trời và hệ truyền thống
Civil time, mean solar time và apparent solar time là các biểu diễn khác nhau. Adapter nâng cao phải công bố dùng biểu diễn nào, kinh độ, equation of time, precision và ranh ngày. Không tự “sửa giờ sinh cho hợp lá số”. Bát tự có chính sách đổi ngày lúc 23 giờ hoặc 00 giờ và khởi vận khác nhau; không dùng một rule cho mọi trường phái. Các chính sách này đang ở phần đặc tả nghiên cứu, chưa được code đầy đủ trong demo.

## 5. Timeline tuổi
Tuổi a là [sinh nhật năm B+a, sinh nhật năm B+a+1). Không cộng 365 ngày. Khung 0–99 có 100 khoảng, không dự báo tuổi thọ. Demo trả events rỗng; sự kiện chỉ được thêm từ dữ liệu lịch sử, kế hoạch hoặc symbolic cycle có nhãn. Không được gọi năm 6 là năm cưới, năm 8 là năm giàu như một dữ kiện dự báo.

## 6. Hypothesis engine
Mỗi phương án có ID, nguồn, field_path, giá trị, thời điểm và trạng thái. Run dùng selected_hypotheses cụ thể; một phép so sánh tạo từng kết quả song song và không tự chọn phương án có lời luận hấp dẫn. Khi sửa một phương án, dependency graph xác định run/report nào cần cập nhật. Mốc tuổi do giấy tờ và mốc tuổi thực tế có thể khác; giao diện phải nêu chứ không lấy trung bình hai ngày.

## 7. Nghiệm thu
Các ca gồm Berlin 2026-10-25 02:30 có 2 ứng viên, New York DST gap, UTC thường, Việt Nam, ngày nhuận, lịch chưa biết, timezone thiếu và năm vượt phạm vi. Runtime receipt lưu Node/ICU/tzdb. Không coi việc một ca đúng là lịch toàn cầu đã được triển khai đầy đủ.

**Tra nguồn:** xem `11_SOURCES/SOURCE_ADDENDUM.csv`; các mã Nxx là nguồn đối chiếu chính thức, không phải mọi nhận định của HNH đã được khoa học xác nhận.


# Quyền dữ liệu, transaction và chống truy cập chéo

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Identity boundary
Session-derived account_id là nguồn danh tính; payload user_id không cấp quyền. Tài khoản khác subject. Grant chứa tenant, subject, grantee, purpose, actions, expiry, revision và state. Giao dịch đọc/ghi kiểm tra processing basis đang hợp lệ và resource state. Consent không thay authentication; entitlement không thay grant. [N09]

## 2. Mô hình tenant
Self workspace có tenant riêng hoặc namespace tương đương theo quyết định schema. Organization membership chỉ cho quyền công việc, không làm tất cả subject trong tổ chức trở thành dữ liệu quản trị có thể đọc. Composite foreign keys dùng (tenant_id,subject_id,id) để child không tham chiếu sang parent khác chủ thể. Role ứng dụng không là owner/superuser và không BYPASSRLS. [N02]

## 3. RLS và pool
Mỗi transaction đặt SET LOCAL context từ server sau xác thực. Không nhận tenant/account headers trực tiếp từ client. Không dựa vào SET dài hạn vì connection pool tái sử dụng kết nối. Policy deny-by-default, FORCE RLS cho bảng phù hợp; quyền của background worker cũng phải qua context tương ứng. Pool/query cache không dùng lại kết quả cá nhân hóa giữa tenant; cache key và grant revision được thiết kế rõ.

## 4. Kiểm tra quyền hai lần cho job
Trước khi enqueue kiểm tra quyền. Khi worker claim job kiểm tra lại. Trước publish/download kiểm tra lại lần nữa. Nếu grant bị thu hồi, job chuyển BLOCKED_REVOKED và không tiếp tục xuất. Snapshot quyền không cho phép job vượt một lần thu hồi về sau. File đã tải xuống không thể hứa thu hồi vật lý.

## 5. Chống cập nhật mất dữ liệu
Update dùng expected_version hoặc If-Match. Server cập nhật với điều kiện version=expected; không có dòng cập nhật trả 412/409 theo contract thống nhất. Không dùng last-write-wins cho ngày sinh, consent hoặc report approval. Người dùng được xem khác biệt và tạo phiên bản kế tiếp có chủ ý.

## 6. Transaction boundaries
Tạo run, outbox event và idempotency receipt trong cùng transaction. Provider call không giữ transaction DB mở lâu. Sau call, ghi kết quả bằng compare-and-set/unique constraint. Nếu worker chết giữa side effect và receipt, phải có reconciliation theo khóa provider; không tuyên bố exactly-once từ queue at-least-once. [N03]

## 7. Negative tests
A không đọc/write/report/download subjectB. Tenant khác cùng idempotency key không chia kết quả. Grant expired/revoked/wrong-purpose bị chặn. Role developer không đọc PII production. Malformed grant fail closed. PostgreSQL policy cần được chạy bằng role runtime thật trên staging, không kiểm thử bằng superuser rồi đánh dấu đạt.

**Tra nguồn:** xem `11_SOURCES/SOURCE_ADDENDUM.csv`; các mã Nxx là nguồn đối chiếu chính thức, không phải mọi nhận định của HNH đã được khoa học xác nhận.


# Tác vụ nền, thanh toán, xóa dữ liệu và tình huống gián đoạn

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Outbox và worker lease
Outbox nằm cùng database transaction với nghiệp vụ. Publisher có lease, retry và trạng thái dispatched; giao lại không tạo side effect mới. Worker nhận operation_id và payload_digest, kiểm tra idempotency theo tenant+operation+key. Payload khác trên cùng khóa trả conflict. Có max_attempts, next_attempt_at, dead-letter và công cụ review có quyền. Không retry vô hạn.

## 2. State machine
Analysis: queued→running→review_required→approved→published, với nhánh blocked/cancelled/failed. Report: draft→reviewed→released→withdrawn/deleted. Payment order: created→pending→paid→fulfilled với nhánh failed/cancelled/refund_requested/refunded. Deletion: requested→verified→blocked_new_work→purging→provider_pending→completed, có legal_hold riêng. Trạng thái là nghiệp vụ, không một chuỗi tùy ý client gửi.

## 3. Thanh toán
Webhook xác minh chữ ký bằng raw body; kiểm tra event ID, merchant/order, currency và amount. Event trùng nhận lại không cấp entitlement thêm. Redirect trình duyệt không là chứng từ thanh toán. Refund có giới hạn tự động theo chính sách được phê duyệt; ngoại lệ cần người có quyền. Đơn vị thu tiền và chính sách thuế chưa chọn không được giả làm hoàn tất.

## 4. Thu hồi và xóa xuyên hệ
Deletion chặn job mới trước khi xóa vật lý. Lineage chỉ ra profile, observation, result, report, vector, cache, export và object liên quan. Provider AI có chính sách lưu giữ phải được đánh giá riêng; chưa xác minh được thì không nói đã xóa mọi nơi. Backup giữ theo lịch và không phục vụ trực tiếp; khi restore phải áp tombstone trước mở traffic. Audit tránh lưu raw sensitive payload để không tạo bản sao không thể xóa.

## 5. Queue failure scenarios
Kiểm thử worker chết trước/giữa/sau render; provider timeout nhưng trả thành công muộn; notification gửi hai lần; grant revoked khi render; file upload hoàn tất nhưng job không ghi receipt; database rollback; không đủ disk; PDF quá lớn; webhook đến ngược thứ tự. Mỗi trường hợp có trạng thái, cách reconcile và người xử lý, không chỉ ghi log error.

## 6. Receipt
Receipt chứa job ID, attempt, input digest, method/report release, access revision, code artifact, latency, chi phí, result digest và trạng thái. Nó không chứa token, URL ký trước còn sống, raw prompts nhạy cảm hoặc secret. Receipt của demo Map là bằng chứng local, không bằng chứng database transaction thật.


# API, schema và báo cáo có thể truy vết

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Hai hợp đồng khác nhau
OpenAPI đích dùng /api/v2 và giữ 64 mã thao tác cũ. Các thao tác mới bổ sung về phương án dữ liệu, preview, method dependencies, impact review và request deletion. Mỗi operation ghi request/response, quyền, idempotency, concurrency, lỗi và trạng thái implementation. File OpenAPI không chứng minh endpoint đã live. [N04]

OpenAPI demo chỉ có health/catalog/run tại loopback. Không cấu hình cookie giả hoặc quảng bá auth của demo là production. JSON Schema 2020-12 kiểm cấu trúc; các ràng buộc liên trường như subject grants, date consistency hoặc probability calibration vẫn cần logic nghiệp vụ và test. [N10]

## 2. Claim là đơn vị kiểm soát nội dung
Sáu loại giữ nguyên: fact, self_report, observation, symbolic_interpretation, derived_metric, model_probability. Mỗi claim có evidence_ref, scope, temporal context và phiên bản. Model probability bắt buộc model release, target, horizon, population và evidence; symbol không được mang probability. confidence nếu dùng phải có kind và definition. “Dữ liệu đầy đủ” không là confidence về đời người.

## 3. Report assembly
Một report snapshot chỉ dùng claims được cấp quyền từ các result cụ thể. Mỗi section giữ supporting_claim_ids, title, narrative_blocks, tables, limitations, questions, actions và review_state. AI viết từ danh sách claims, không đọc cả kho khách. Renderer HTML/PDF/Word dùng chung content model, không tính công thức riêng.

## 4. Chín template, không chín đoạn văn chung
Level 1 cần calculation traces và input uncertainty; Level 2 cần các ví dụ người dùng xác nhận; Level 3 cần dữ liệu hành vi theo khoảng thời gian; Level 4 cần kịch bản nguồn lực; Level 5 cần giới hạn dữ liệu hai bên; Level 6 tách bốn đường thời gian; Level 7 ghi điều kiện ảnh; Level 8 ghi lựa chọn sứ mệnh; Level 9 liên kết và loại lặp. Thiếu input tạo section unavailable rõ ràng, không tăng trang bằng văn bản sáo rỗng.

## 5. Định dạng lỗi và thay phiên bản
400 cho JSON không hợp lệ;401 chưa xác thực;403/404 theo anti-enumeration policy;409 conflict nghiệp vụ;412 version precondition;422 dữ liệu hợp lệ JSON nhưng không đạt schema;429 quota;503 phụ thuộc tạm không sẵn. Problem Details không lộ query hay dữ liệu subject khác. Deprecated endpoint có sunset plan và adapter giới hạn; không giữ endpoint cũ không auth chỉ để “tương thích”. [N05]

## 6. Report security
Render chạy sandbox, mặc định không network egress. Chỉ cho tài nguyên đã allowlist, không nhận URL tùy ý để tránh SSRF. Tệp private, kiểm quyền mỗi lần cấp link. Link ký trước có thời hạn và vẫn có thể được dùng đến hết hạn; khi cần revoke tức thì dùng proxy download kiểm quyền. Word và PDF phải có text thật, mục lục, font tiếng Việt và không chứa metadata cá nhân thừa.

**Tra nguồn:** xem `11_SOURCES/SOURCE_ADDENDUM.csv`; các mã Nxx là nguồn đối chiếu chính thức, không phải mọi nhận định của HNH đã được khoa học xác nhận.


# Hiệu năng, bộ nhớ đệm và vận hành ít thao tác

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Đặt ngân sách theo loại tác vụ
Phép số ngắn nên nhanh và có thể chạy local cho guest; pipeline có dữ liệu riêng chạy qua server; render sách và AI chạy nền. Không đặt một SLA chung cho phép chia 80 và sách 600 trang. Benchmark tham chiếu trong gói chỉ đo CPU cục bộ không mạng, không DB, không AI; cần load test thật trước cam kết.

## 2. Cache có provenance và ACL
Cache key phải gồm tenant/subject hoặc namespace public, input digest, method version, config digest, source/table digest, locale version và policy revision. Không cache kết quả cá nhân theo ngày sinh chung. Cache dữ liệu công khai dùng riêng với cache profile. Dữ liệu thu hồi phải invalidation theo lineage; cache không trở thành nơi chứa bản cũ còn truy cập được.

## 3. Tính gia tăng
Một đổi mục tiêu không làm lại lịch thiên văn; đổi ngày sinh không cần render lại tài liệu nguồn công khai. DAG nêu inputs của từng node, tính hash subtree và chỉ chạy các node bị ảnh hưởng. Khi thay rule table, tạo impact job tìm report phụ thuộc, không sửa PDF lịch sử âm thầm. Chạy lại có trạng thái và quyền, không tự tính phí ngoài phạm vi.

## 4. Quan sát hệ thống
Metrics gồm throughput, latency, queue age, rejection reason, failed grant, method failure, render error, review backlog, cost/token và correction rate. Log là sự kiện kỹ thuật tối thiểu; không log tên, số điện thoại, lời tự thuật hoặc hình ảnh. Trace ID nối gateway/job/report nhưng không được dùng làm token truy cập.

## 5. Circuit breaker và ngân sách
AI provider timeout/quota có fallback về công cụ xác định hoặc báo chưa sẵn sàng. Không đổi sang model chưa được phép xử lý loại dữ liệu đó. Mỗi SKU có token cap, retry cap, render count, storage retention và reviewer budget. Khi vượt ngân sách, pause/notify theo chính sách, không tự mua thêm quota hoặc trừ tiền khách.

## 6. SLO đích và diễn tập
Giữ mục tiêu thiết kế của bộ cũ, nhưng đo lại trên tải thật. Restore phải phục hồi database, object mapping, rule registry, grants, tombstones và báo cáo cùng phiên bản. RPO/RTO không chỉ là dòng trong tài liệu: cần receipt diễn tập, dữ liệu tổng hợp, thời gian đo và sai khác. Rollback về safe mode nếu không có artifact an toàn.


# Khống chế P0 và chuyển dữ liệu không mất lịch sử

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. V2 không tự sửa production
Gói mới là kế hoạch và mã tham chiếu. Giữ nguyên P0 packet cũ; bổ sung readiness checklist và tests. Các endpoint legacy cần khóa phía server trước khi mở thu dữ liệu. Xác thực phải bắt nguồn từ phiên hợp lệ, không payload.user_id. Chỉ sửa storage token không giải quyết cấp phiên sai danh tính.

## 2. Khoanh vùng legacy
Nhóm A: raw data có nguồn và quyền có thể kiểm tra. Nhóm B: chưa rõ ownership hoặc tính toàn vẹn, cần quarantine. Nhóm C: điểm/timeline/lời luận từ demo, lưu experimental_legacy và không dùng làm sự thật. Chuyển dữ liệu theo bảng mapping từng field với rule transform và lý do. Không chuyển một câu AI từng viết thành sự kiện đời thật.

## 3. Trình tự migration
Inventory→read-only snapshot riêng tư→mapping→dry-run synthetic→rehearsal data được phép→đối soát số lượng và checksum có phạm vi→phê duyệt→write freeze ngắn theo kế hoạch→migrate→reconcile→chuyển traffic→giám sát→decommission theo retention. Không xóa D1 ngay khi thấy PostgreSQL có dữ liệu. Dual-write cần thiết kế nhất quán riêng; không bật cho tiện.

## 4. Build và supply chain
Build public theo allowlist, không sao chép toàn repo rồi bỏ vài thư mục. Bộ V2 và toàn bộ baseline nằm dưới docs để không lẫn vào public assets. Dù vậy pipeline phải kiểm tra dist không có sql, report riêng, archive, test fixture hoặc secrets. Pin dependency/lockfile, kiểm license, SBOM, secret scan và provenance artifact. Không dùng commit-dirty cho production release.

## 5. Phiên và browser
Secure/HttpOnly cookies cùng CSRF phù hợp cho web. Quyền cookie không thay object authorization. Mobile/native có OIDC/PKCE và keychain riêng khi được triển khai; không chia sẻ token qua URL hoặc localStorage. Recovery không dùng tên/ngày sinh làm bí mật. Browser không được chứa admin credential hoặc service role.

## 6. Dữ liệu nghiêm trọng và chuyển giao
Tiếp nhận sức khỏe/ảnh/trẻ em/quan hệ nhiều bên chờ scope gate. Hội đồng phương pháp không có quyền mặc định đọc khách hàng thật. Khi partner rời hệ, cần chuyển hỗ trợ và quyền dữ liệu hợp lệ, không dùng dữ liệu làm đòn bẩy. Những bước này phải có owner và evidence, không chỉ có chính sách công khai.


# Mở rộng bộ máy nâng cao mà không tạo kết quả giả

**Life Code OS · Bản nâng cấp bảo toàn V2 · 20/10/2026**  
**Trạng thái:** Đặc tả để triển khai và rà soát; không phải chứng nhận production.

## 1. Giữ tầm nhìn đầy đủ
Tất cả 20 họ tri thức ở bản cũ được bảo lưu. V2 không giản lược HNH thành ba phép cộng số; nó tách lộ trình tính toán được ngay và nghiên cứu cần làm tiếp. Catalogue nâng cao phải cho Founder thấy chính xác sách, công thức, bảng và demo nào đang thiếu, ai chủ trì và khi nào được review.

## 2. Bát tự
Adapter cần input civil time, timezone lịch sử, place/longitude khi phương pháp dùng solar time, lịch tiết khí và policy đổi ngày. Output gồm bốn trụ, tàng can, quan hệ can chi và method-specific calculations. Dụng thần, vượng–suy và khởi vận là rule modules có version riêng. Test mốc tiết khí trước/sau,23h/0h, không rõ giờ, nhiều thời điểm UTC ứng viên và ngày ở vùng lịch sử. Không sử dụng seed sinh risk để thay những phần chưa có.

## 3. Tử Vi
Input cần lịch âm được quy đổi có nguồn và chính sách tháng nhuận. Output là positions, houses, stars, transformations và cycles theo một trường phái. Cần golden examples từ nguồn độc lập, không chỉ tự dùng cùng engine để tạo expected. Những nhãn nghề nghiệp hoặc gia đạo là symbolic_interpretation, không dữ kiện về đời tư.

## 4. Chiêm tinh và Jyotish
Ephemeris phải pin version/license, thang thời gian, hệ hoàng đạo, ayanāṃśa khi áp dụng, hệ nhà, polar-latitude behavior và precision. Trường hợp tọa độ/giờ không đủ trả partial. Không trộn sidereal và tropical mà không ghi cấu hình. Đầu ra thiên văn chính xác không tự làm phần luận tâm lý thành xác thực khoa học.

## 5. Kinh Dịch và Tam thức
Định nghĩa rõ công cụ lấy quẻ, câu hỏi, thời điểm, hào từ dưới lên, hào động, quẻ biến và table source. Kỳ Môn/Lục Nhâm/Thái Ất cần graph riêng của quy tắc lập bàn, không biến một binary hexagram demo thành toàn bộ Tam thức. Mỗi policy phải có bảng so khác biệt trường phái và ví dụ cần sửa nếu đổi rule.

## 6. Hình thái và giọng nói
Giữ kho nghiên cứu tướng tay/mặt/chân, nhưng sản phẩm chỉ mô tả quan sát có điều kiện chụp và sai số. Không tự phát hành adapter suy nhân cách/đạo đức/bệnh từ ảnh. Voice features có thể đo như tốc độ/cường độ khi có thiết bị/điều kiện phù hợp; không đồng nhất âm sắc với ý định hoặc phẩm chất. Chất liệu truyền thống được dùng ở phần giáo dục có nhãn, không cấp phán quyết cá nhân.

## 7. Tiêu chí kết thúc một nghiên cứu
Một nghiên cứu có thể kết thúc bằng RELEASE_CANDIDATE, NEED_MORE_SOURCE, SCOPE_RESTRICTED hoặc NOT_SUITABLE_FOR_PRODUCT. Không bắt mọi nhánh phải ra kết quả tích cực để giữ tầm nhìn Founder. Công trình được lưu đầy đủ kể cả kết quả không ủng hộ một giả thuyết.


# Giao thức một lần phân tích: từ yêu cầu tới phát hành

**Life Code OS · V2 · 20/10/2026**  
**Phạm vi:** Đặc tả triển khai; mã demo chỉ là tham chiếu cục bộ, chưa phải production.

## 1. Giao dịch nhận yêu cầu
POST analysis-runs không nhận điểm hoặc kết luận từ client. Client gửi subject_id, profile_version_id, hypothesis_ids, product_release_id, selected_method_release_ids và khóa idempotency. Server lấy account từ phiên đã xác thực, kiểm tra grant, purpose, điều kiện sản phẩm và phiên bản hồ sơ. product_release là danh mục do server quản lý; client không được thay danh sách dữ liệu bắt buộc để nâng coverage.

Giới hạn body, số phương pháp, độ dài chuỗi và khoảng thời gian phải được kiểm tra trước khi lập kế hoạch. Nếu hồ sơ thiếu dữ liệu bắt buộc, trả kết quả needs_input có tên trường và lý do; dữ liệu tùy chọn thiếu không biến thành lỗi toàn bộ. Một yêu cầu thay đổi mục đích xử lý không được tái sử dụng sự đồng ý dành cho mục đích cũ.

Trong một transaction: tạo analysis_run ở trạng thái queued; lưu manifest đầu vào bất biến; tạo idempotency receipt; tạo outbox event. Unique constraint trên tenant_id, operation_name và idempotency_key ngăn hai request đồng thời tạo hai nghiệp vụ. Nếu khóa trùng và payload_digest giống nhau, trả receipt của lần trước. Nếu payload khác, trả 409 và không thực hiện phần mới.

## 2. Lập đồ thị phụ thuộc
Mỗi node gồm node_id, method_release_id, input_paths, dependencies, output_schema, cost_budget và timeout_budget. Đồ thị phải được kiểm tra node trùng, phụ thuộc thiếu và chu trình trước khi chạy. Các node độc lập có thể chạy cùng đợt trong giới hạn concurrency; node phụ thuộc chỉ bắt đầu khi đầu ra cần dùng đã hoàn tất và hợp lệ.

Ví dụ: chuẩn hóa tên và chuẩn hóa ngày chạy độc lập. Chu kỳ số phụ thuộc ngày; bản đồ tuổi phụ thuộc ngày và as_of; báo cáo phụ thuộc các kết quả đã được phép dùng. Nếu giờ sinh chưa rõ, node dùng giờ bị chặn, nhưng phép quy đổi tên không bị mất theo. Node thất bại không được thay bằng hằng số đẹp.

## 3. Worker nhận và xử lý
Worker claim job với lease có thời hạn; kiểm tra lại trạng thái chủ thể, grant revision và deletion barrier. Việc một request hợp lệ lúc tạo không bảo đảm nó còn hợp lệ sau khi chờ hàng đợi. Worker chỉ lấy đúng snapshot được ghi trong run, không đọc hồ sơ mới nhất rồi tạo một báo cáo nửa cũ nửa mới.

Mỗi node ghi started_at, finished_at, implementation_version, source_digest, input_digest, output_digest, trạng thái và mã lỗi. Dữ liệu nhạy cảm không được đưa thẳng vào log. Công cụ không có nguồn hoặc chưa phát hành trả METHOD_NOT_RELEASED. Lỗi tạm thời có thể retry theo ngân sách; lỗi dữ liệu, quyền hoặc phương pháp không retry tự động.

## 4. Hủy, thu hồi và hết hạn
Cancel từ người có quyền chuyển run sang cancel_requested. Worker kiểm tra giữa các bước và dừng tại điểm an toàn. Cancel không được tuyên bố đã hoàn tất khi tác vụ bên ngoài còn chạy; trạng thái phải chỉ rõ cleanup_pending nếu cần thu hồi artifact. Khi quyền bị thu hồi, kết quả chưa phát hành không được cấp link tải.

Một run hoàn thành tính toán vẫn có thể chuyển review_required. approve là nghiệp vụ riêng: người duyệt, phạm vi, phiên bản và lý do. Nếu dữ liệu nguồn thay đổi trước phát hành, bản nháp được ghi stale hoặc yêu cầu chạy lại, không âm thầm thay nội dung.

## 5. Phát hành và truy vết
Tạo report_snapshot từ danh sách claim cụ thể. Phát hành phải kiểm tra lại scope, policy revision và quyền phương pháp. Renderer chỉ nhận content tree đã chốt; không tự gọi thêm AI hoặc tính lại công thức. Artifact được ghi hash, MIME, dung lượng, phiên bản renderer và trạng thái riêng tư.

Khi download, kiểm tra quyền của account với chính report. Khóa đoán khó không thay authorization. Chủ sở hữu có thể xem lịch sử phiên bản, lý do hiệu chỉnh và phần nào không còn phù hợp; hệ không ghi đè PDF cũ rồi tiếp tục dùng cùng ID như chưa có thay đổi.

## 6. Bằng chứng nghiệm thu
Đội QA cần chạy tối thiểu: gửi request trùng đồng thời; đổi body trên cùng khóa; hủy khi đang render; thu hồi grant lúc đang chờ; sửa ngày sinh khi node đang chạy; worker chết sau tạo artifact; node con chạy sai thứ tự; phương pháp bị freeze trước publish. Mỗi ca cần kết quả kỳ vọng, trạng thái cuối và bằng chứng không có thêm side effect.

Demo DAG, cache key, policy và ledger trong gói chỉ mô phỏng các phần logic trên một process. Bằng chứng transaction, lease và concurrency nhiều worker phải được tạo bằng PostgreSQL và queue staging thật. [N02, N03, N05]


# Nguồn, phụ thuộc kết quả và cập nhật không làm mất lịch sử

**Life Code OS · V2 · 20/10/2026**  
**Phạm vi:** Đặc tả triển khai; mã demo chỉ là tham chiếu cục bộ, chưa phải production.

## 1. Mỗi kết quả có đường đi ngược
Lineage bắt đầu ở source_assertion hoặc self-report, đi qua profile_version, input manifest, method release, method result, claim, report section và artifact. Mọi cạnh phải có loại quan hệ: used_input, derived_from, interpreted_by, supports, rendered_as hoặc supersedes. Không dùng một chuỗi văn bản “nguồn: HNH” thay cho chuỗi này.

Người dùng có thể đọc một lời giải ngắn; chuyên gia được xem phần nguồn được cấp quyền; người vận hành xem metadata tối thiểu. Một liên kết nguồn không tự cấp quyền đọc dữ liệu gốc của người khác.

## 2. Nguồn không chỉ là URL
source_edition cần tác phẩm, tác giả/đơn vị, phiên bản, ngôn ngữ, vị trí trang/mục, ngày truy xuất, quyền sử dụng và người rà soát. Chỉ mục đa ngôn ngữ giữ thuật ngữ gốc và bản dịch được duyệt. Nếu chỉ có mục lục hoặc bài quảng bá, read_status không được đổi thành full_text_reviewed.

Với bảng số, table artifact có digest và trạng thái. Quy tắc 0→80, cách xử lý số 5 hoặc chính sách Y là cấu hình có ID, không nằm trong câu chữ tùy ý của prompt. Nếu thiếu nguyên văn bảng, nội dung gốc để null; một câu diễn giải mới phải ghi rõ do biên tập HNH, không giả làm lời sách.

## 3. Ảnh hưởng khi dữ liệu hoặc quy tắc đổi
Sửa tên chỉ làm những node sử dụng tên mất hiệu lực. Sửa ngày sinh tác động birth calculation, cycle, timeline và phần report dùng chúng. Sửa giá tiền của SIM không làm đổi modulo80. Sửa lời chú giải nhưng không đổi bảng phân loại chỉ cần dựng lại narrative liên quan, không tính lại mọi node.

Bộ impact analysis đi trên đồ thị phụ thuộc và xuất affected/unaffected, lý do, chi phí dự kiến và mức cần phê duyệt. Không chạy lại hàng loạt trên dữ liệu thật khi chưa có quyền và ngân sách. Danh sách affected là đề xuất công việc, không phải phép tự truy cập.

## 4. Thiết kế bộ nhớ đệm
Khóa cache gồm namespace, tenant_id khi dữ liệu riêng, subject_id, processing_purpose, access_revision, profile_version_id, method_release_id, input digest và cấu hình. Không dùng duy nhất ngày sinh làm khóa cache. Phần dữ liệu nhạy cảm có entropy thấp không được công khai qua hash dễ dò; HMAC và quản lý khóa là thiết kế production cần review riêng.

Cache hit vẫn phải kiểm tra quyền và trạng thái thu hồi. TTL không thay deletion workflow. Một tệp bị gỡ khỏi DB nhưng vẫn có public URL hoặc nằm trong vector index là dữ liệu chưa được xóa đầy đủ.

## 5. Đọc nhiều giả thuyết mà không ép chọn
Ngày sinh giấy tờ và ngày sinh thực tế được lưu thành các giả thuyết riêng có nguồn. Hệ tính từng nhánh và hiển thị phần khác nhau. Không lấy trung bình ngày sinh, không chọn phương án có lời luận đẹp và không dùng nhận xét “đúng hơn” để ghi đè dữ liệu gốc.

Mỗi so sánh nêu method version, trường thay đổi, kết quả thay đổi và phần bất biến. Quyết định chọn giả thuyết phải được ghi bởi người có quyền với lý do. Khi chưa chọn, các kết quả phụ thuộc hiển thị chưa chốt; những phần độc lập vẫn hoạt động.

## 6. Quản trị thu hồi nguồn
Nếu license hết hiệu lực hoặc method bị phát hiện sai, registry chuyển trạng thái phù hợp và chặn run mới. Review board xác định có cần rút báo cáo, bổ sung thông báo hay chỉ chặn phát hành tương lai. Snapshot lịch sử được giữ theo chính sách pháp lý và quyền dữ liệu; không tiếp tục sử dụng như kết quả còn hiệu lực.

Báo cáo đã tải ra ngoài không thể bị thu hồi vật lý bởi phần mềm. Hệ phải nói rõ giới hạn đó và cung cấp phiên bản hiệu chỉnh. Chỉ đổi số version ở footer không đủ nếu nội dung đã gây hiểu sai.


# Adapter, ma trận demo và cách chuyển mã tham chiếu thành sản phẩm

**Life Code OS · V2 · 20/10/2026**  
**Phạm vi:** Đặc tả triển khai; mã demo chỉ là tham chiếu cục bộ, chưa phải production.

## 1. Hợp đồng adapter
Một adapter nhận input đã kiểm tra, cấu hình bất biến, source artifact và as_of. Nó trả calculation, trace, missing inputs, warnings và limitations. Adapter không truy cập tài khoản, cơ sở dữ liệu production hoặc mô hình AI trực tiếp. Service orchestration chịu trách nhiệm quyền và việc đọc dữ liệu; pure calculation chịu trách nhiệm tính đúng.

Các thông tin số dùng đơn vị cụ thể. Với tiền, minor units là chuỗi số nguyên trong JSON và BigInt trong runtime; không đi qua float. Với ngày, chuỗi ISO là ngày dân dụng theo lịch đã khai báo, không tự parse bằng Date rồi để timezone của máy làm thay đổi ngày.

## 2. Mức độ triển khai trong gói
16 họ công thức LCF-01–LCF-16 có mã tham chiếu. Ba hàm về DAG, impact analysis và cache key là công cụ điều phối; các hàm policy/report/pipeline là mô phỏng nghiệp vụ để thử kết nối. Tổng cộng 27 khóa dispatcher và 90 tình huống có thể chạy tại máy. Không có 27 môn được tuyên bố triển khai khoa học.

Một số phương pháp nâng cao được giữ trong catalog nhưng chưa chạy: Bát tự đầy đủ, Tử Vi, ephemeris/chiêm tinh, Jyotish, Tam thức, lịch âm lịch sử, Psychomatrix nhiều trường phái và phân tích văn tự ngoài Latin. Chúng có điều kiện đầu vào, nguồn phải bổ sung và cách nghiệm thu riêng.

## 3. Các loại demo phải cùng tồn tại
Có ca đúng; ca sai định dạng; ca thiếu dữ liệu; ca mâu thuẫn; ca chưa có quyền; ca bị chính sách cấm; ca phương pháp chưa phát hành; ca xung đột phiên bản; ca lặp yêu cầu; ca đọc và xuất kết quả cho người dùng. Một hệ chỉ minh họa đầu vào đẹp không đủ để DEV biết cách xử lý thực tế.

Ba hồ sơ xuyên suốt là dữ liệu tổng hợp: đủ dữ liệu nền; thiếu giờ sinh; nhiều giả thuyết ngày sinh. Các tên trong demo không dùng để nhận diện người thật. Mỗi hồ sơ trả bốn phần nội dung, dữ liệu còn thiếu và xác suất null. Nội dung gợi ý hành động được gắn vai trò planning_guidance; không giả làm self-report của người dùng.

## 4. Bốn loại kiểm thử
Unit/property tests kiểm số nguyên, Unicode, ngày nhuận, 64 cặp, 64 quẻ × 64 mặt nạ và invariants. HTTP tests kiểm loopback, body limits, định dạng lỗi và static allowlist. Browser tests kiểm các ca hiển thị, dữ liệu máy, tự nhập và các độ rộng màn hình. Production tests về IdP, PostgreSQL, payment, R2, queue và xóa dữ liệu chưa nằm trong demo.

Bản receipt ghi môi trường Node, ICU và tzdb thật. Việc dùng tzdb2025b trong Node tham chiếu không có nghĩa đó là dữ liệu múi giờ mới nhất của thế giới; production phải khóa và cập nhật phiên bản theo chính sách riêng. Phạm vi local-time resolver được công bố, không dùng nó để khẳng định đã giải đúng mọi lịch sử thiên văn.

## 5. Đọc benchmark đúng cách
Benchmark chạy từng phương pháp trong một process, không có mạng, DB, AI hay dựng sách. Thời gian millisecond chỉ mô tả lần chạy đó. Không chuyển kết quả 250 vòng lặp thành SLA, năng lực phục vụ người dùng đồng thời hoặc bằng chứng có thể xuất 600 trang tức thì.

Bài thử staging về sau phải ghi máy, vùng, số người dùng đồng thời, payload, cache hit rate, độ dài nội dung, percentile, lỗi và ngân sách. Tối ưu sau khi biết nút thắt; không bỏ kiểm quyền để giảm latency.

## 6. Chuyển từ reference sang production
Thứ tự: review phương pháp → đưa pure functions vào package canonical → contract tests → tích hợp auth/purpose → transaction/outbox → observability → staging negative tests → pilot có consent → release receipt. Không sao chép server demo lên Worker public vì demo cố ý không có auth, database hay thanh toán.

Mọi adapter mới phải có ít nhất ví dụ nguồn được đối chiếu độc lập, kiểm thử biên, kiểm thử dữ liệu thiếu, câu giải thích ngắn cho người dùng và danh sách nhận định không được phép. Một phương pháp chưa đạt có thể được hiển thị như tài liệu nghiên cứu, nhưng nút “Tính” không được tạo kết quả thay thế.


# Danh mục công thức, ma trận và điều kiện triển khai



**Ngày:** 20/10/2026. Bản tham chiếu có thể chạy khác với phương pháp đã được phê duyệt production.



## LCF-01 — Mã đuôi 80

**Công thức hoặc phép biến đổi:** r = N mod 80; q = floor(N / 80)

**Đầu vào:** Chuỗi đúng bốn chữ số ASCII và chính sách zero_policy.

**Đầu ra được hiểu thế nào:** Thương, số dư và mã tra trong bảng; không phải xác suất.

**Trường hợp biên:** Giữ nguyên số 0 đầu; số dư 0 mặc định chưa ánh xạ. Chỉ dùng as80 khi được chọn rõ; không tính qua số thực.

**Mã tham chiếu:** `06_DEMO_LAB/src/numbers.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M06. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-001:** Đuôi 6789 · quy tắc unmapped

```json

{"suffix":"6789","zero_policy":"unmapped"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"lookup_code":69}}`.

**Các ca liên quan:** DEMO-001, DEMO-002, DEMO-003, DEMO-004, DEMO-005, DEMO-006, DEMO-007, DEMO-008, DEMO-009.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-02 — Cặp số chồng lấn

**Công thức hoặc phép biến đổi:** p_i = (d_i, d_(i+1)), với i từ 0 đến n−2

**Đầu vào:** Chuỗi 2–32 chữ số; chọn strict hoặc bridge5_diagnostic.

**Đầu ra được hiểu thế nào:** Nhóm của từng cặp, phần chưa xử lý và độ bao phủ phép phân loại.

**Trường hợp biên:** Trong strict, cặp có 0 hoặc 5 chưa được gán nhóm. Cặp 55 không mặc nhiên là Phục vị.

**Mã tham chiếu:** `06_DEMO_LAB/src/numbers.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M07. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-010:** Chuỗi 1234 · giữ phần chưa biết

```json

{"digits":"1234","policy":"strict"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"known":3,"total":3,"counts":{"TM":1,"HH":1,"DN":1}}}`.

**Các ca liên quan:** DEMO-010, DEMO-011, DEMO-012, DEMO-013, DEMO-014, DEMO-015, DEMO-016.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-03 — Ma trận chữ số thô

**Công thức hoặc phép biến đổi:** count(k) = Σ I(d_i = k); tổng đường = Σ count(k)

**Đầu vào:** Chuỗi chữ số gốc theo phạm vi của công cụ.

**Đầu ra được hiểu thế nào:** Số lần xuất hiện của các chữ số và tổng tám đường; không đo năng lực con người.

**Trường hợp biên:** Không thêm các số làm việc khi chưa có quy tắc nguồn. Số 0 được ghi riêng.

**Mã tham chiếu:** `06_DEMO_LAB/src/numbers.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M08. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-017:** Đếm tần suất chữ số thô

```json

{"digits":"20000229"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"zero_count":4}}`.

**Các ca liên quan:** DEMO-017.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-04 — Đặc trưng dãy số

**Công thức hoặc phép biến đổi:** Tổng chữ số; căn rút gọn; nhóm lặp; tính đối xứng

**Đầu vào:** Chuỗi chữ số với giới hạn độ dài được kiểm tra.

**Đầu ra được hiểu thế nào:** Các thuộc tính của chuỗi, không phải điểm trí nhớ hoặc độ hợp mệnh.

**Trường hợp biên:** Chuỗi đối xứng không tự chứng minh dễ nhớ đối với người sử dụng.

**Mã tham chiếu:** `06_DEMO_LAB/src/numbers.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** Mô-đun bổ sung. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-018:** Chuỗi đối xứng không phải số phận

```json

{"digits":"12344321"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"palindrome":true}}`.

**Các ca liên quan:** DEMO-018.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-05 — Quy đổi tên Latin có truy vết

**Công thức hoặc phép biến đổi:** value(c) = ((ord(c) − 65) mod 9) + 1, với c thuộc A–Z

**Đầu vào:** Tên Việt hoặc Latin; cấu hình chữ Y và cách giữ số đặc biệt.

**Đầu ra được hiểu thế nào:** Tổng từng từ, tổng tên, nguyên âm, phụ âm và chuỗi bước tính.

**Trường hợp biên:** Giữ tên gốc; chuẩn hóa NFC; quy đổi Đ thành D ở chuỗi dẫn xuất. Từ chối văn tự chưa được hỗ trợ.

**Mã tham chiếu:** `06_DEMO_LAB/src/names.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M02, M03. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-021:** Quy đổi có giữ nguyên tên: Đỗ An

```json

{"name":"Đỗ An"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"latin":"DO AN","sum":16,"vowel_sum":7,"consonant_sum":9}}`.

**Các ca liên quan:** DEMO-021, DEMO-022, DEMO-023, DEMO-024, DEMO-025, DEMO-026, DEMO-027, DEMO-028, DEMO-029.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-06 — Khoảng tuổi 0–99

**Công thức hoặc phép biến đổi:** [anniv(B, a), anniv(B, a+1))

**Đầu vào:** Ngày sinh ISO, ngày đối chiếu as_of và chính sách ngày nhuận.

**Đầu ra được hiểu thế nào:** 100 khoảng tuổi; danh sách sự kiện mặc định rỗng.

**Trường hợp biên:** Ngày 29/02 dùng chính sách feb28 hoặc mar01 đã chọn rõ. Không suy đoán tuổi thọ.

**Mã tham chiếu:** `06_DEMO_LAB/src/time.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M09. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-037:** Timeline 100 khoảng tuổi, không biến cố

```json

{"birth_date":"2000-02-29","as_of":"2026-10-20","leap_policy":"feb28"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"age_at_as_of":26}}`.

**Các ca liên quan:** DEMO-037, DEMO-038.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-07 — Quy đổi ngày sinh

**Công thức hoặc phép biến đổi:** all_digits hoặc reduced_components theo cấu hình

**Đầu vào:** Ngày sinh ISO, biến thể cộng và quy tắc rút gọn.

**Đầu ra được hiểu thế nào:** Tổng trung gian và từng bước rút gọn theo đúng cấu hình.

**Trường hợp biên:** Không trộn cách giữ 11, 22, 33 giữa các phương pháp.

**Mã tham chiếu:** `06_DEMO_LAB/src/time.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M04. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-030:** Ngày nhuận hợp lệ

```json

{"birth_date":"2000-02-29"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"raw_digit_sum":15}}`.

**Các ca liên quan:** DEMO-030, DEMO-031, DEMO-032, DEMO-033, DEMO-034.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-08 — Chu kỳ năm và tháng biểu tượng

**Công thức hoặc phép biến đổi:** r(r(ngày) + r(tháng) + r(tổng chữ số năm))

**Đầu vào:** Ngày sinh; năm xét; quy ước năm dương lịch hoặc từ sinh nhật; as_of khi cần.

**Đầu ra được hiểu thế nào:** Mã năm hoặc tháng theo quy ước, không phải sự kiện được dự báo.

**Trường hợp biên:** Giữ rõ chính sách chuyển năm và không gọi mã số là năm cưới, năm giàu hoặc năm tai họa.

**Mã tham chiếu:** `06_DEMO_LAB/src/time.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M05. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-035:** Chu kỳ biểu tượng theo năm dương lịch

```json

{"birth_date":"1990-03-14","year":2026,"month":10}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"personal_year":9,"personal_month":1}}`.

**Các ca liên quan:** DEMO-035, DEMO-036.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-09 — Thời điểm UTC ứng viên từ giờ địa phương

**Công thức hoặc phép biến đổi:** Liệt kê độ lệch múi giờ; đối chiếu ngược về giờ địa phương

**Đầu vào:** Ngày, giờ địa phương và định danh múi giờ IANA.

**Đầu ra được hiểu thế nào:** Không có, một hoặc hai thời điểm UTC ứng viên trong các trường hợp minh họa.

**Trường hợp biên:** Phạm vi demo 1900–2100; ghi phiên bản Intl/ICU. Không thay thư viện lịch pháp hoặc thiên văn đầy đủ.

**Mã tham chiếu:** `06_DEMO_LAB/src/time.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M01. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-040:** Việt Nam · thời điểm duy nhất

```json

{"date":"2000-02-29","time":"04:25","time_zone":"Asia/Ho_Chi_Minh"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"state":"exact"}}`.

**Các ca liên quan:** DEMO-040, DEMO-041, DEMO-042, DEMO-043, DEMO-044.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-10 — So sánh giả thuyết ngày sinh

**Công thức hoặc phép biến đổi:** Tính độc lập cho từng giả thuyết, không trộn đầu vào

**Đầu vào:** Từ hai đến năm phương án có ID và ngày ISO hợp lệ.

**Đầu ra được hiểu thế nào:** Kết quả riêng cho mỗi phương án; selected mặc định là null.

**Trường hợp biên:** Không lấy trung bình ngày sinh và không tự chọn phương án vì lời diễn giải hấp dẫn hơn.

**Mã tham chiếu:** `06_DEMO_LAB/src/time.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M01. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-039:** Hai phương án năm sinh giữ riêng

```json

{"hypotheses":[{"id":"paper","birth_date":"1970-05-10"},{"id":"family","birth_date":"1972-05-10"}]}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"selected":null}}`.

**Các ca liên quan:** DEMO-039.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-11 — Độ đầy đủ đầu vào

**Công thức hoặc phép biến đổi:** Σ(trọng số máy chủ × có dữ liệu) / Σ(trọng số máy chủ)

**Đầu vào:** Mã phiên bản sản phẩm và danh sách trường đầu vào hợp lệ.

**Đầu ra được hiểu thế nào:** Tỷ lệ dữ liệu đã có trong phạm vi sản phẩm; không phải độ chính xác về cuộc đời.

**Trường hợp biên:** Mẫu số do máy chủ khóa; điểm và trọng số tự gửi từ client bị từ chối.

**Mã tham chiếu:** `06_DEMO_LAB/src/metrics.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** Mô-đun bổ sung. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-045:** Coverage lấy mẫu số từ registry

```json

{"product_release":"self-signal.demo.2","valid_field_ids":["name"]}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"numerator":1,"denominator":3}}`.

**Các ca liên quan:** DEMO-045, DEMO-046.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-12 — Tiến độ công việc đến hạn

**Công thức hoặc phép biến đổi:** Số việc hoàn thành đến hạn / số việc không hủy đến hạn trong cửa sổ

**Đầu vào:** Danh sách công việc và khoảng ngày đối chiếu.

**Đầu ra được hiểu thế nào:** Số việc đủ điều kiện, số hoàn thành và tỷ lệ nếu mẫu số khác 0.

**Trường hợp biên:** Loại việc hủy và việc ngoài cửa sổ; mẫu số 0 trả null, không giả thành 100%.

**Mã tham chiếu:** `06_DEMO_LAB/src/metrics.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M10. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-047:** Tiến độ có thời hạn và quy tắc hủy

```json

{"actions":[{"id":"A1","due_on":"2026-10-21","state":"done"},{"id":"A2","due_on":"2026-10-22","state":"scheduled"},{"id":"A3","due_on":"2026-10-23","state":"cancelled"},{"id":"A4","due_on":"2026-11-01","state":"done"}],"window_start":"2026-10-20","window_end":"2026-10-30"}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"completed":1,"due":2,"ratio":0.5}}`.

**Các ca liên quan:** DEMO-047, DEMO-048.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-13 — Dòng tiền theo đơn vị nhỏ nhất

**Công thức hoặc phép biến đổi:** Tổng tiền vào − tổng tiền ra, tách theo từng loại tiền

**Đầu vào:** Mã tiền tệ và các số tiền ở dạng chuỗi số nguyên của đơn vị nhỏ nhất.

**Đầu ra được hiểu thế nào:** Tổng thu, tổng chi và chênh lệch, được trả dưới dạng chuỗi.

**Trường hợp biên:** Dùng BigInt; không cộng lẫn các loại tiền hoặc tự quy đổi tỷ giá. Không dự báo lợi nhuận.

**Mã tham chiếu:** `06_DEMO_LAB/src/metrics.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** M13. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-049:** Dòng tiền số nguyên · không dự báo

```json

{"currency":"VND","entries":[{"currency":"VND","kind":"inflow","minor_units":"12000000"},{"currency":"VND","kind":"outflow","minor_units":"7500000"}]}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"net_minor":"4500000"}}`.

**Các ca liên quan:** DEMO-049, DEMO-050.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-14 — Tổng hợp nhật ký tự khai

**Công thức hoặc phép biến đổi:** Số quan sát, trung bình và trung vị theo từng trường

**Đầu vào:** Ngày, mã trường môi trường và điểm tự khai từ 0 đến 10.

**Đầu ra được hiểu thế nào:** Thống kê mô tả những quan sát người dùng đã nhập.

**Trường hợp biên:** Không suy ra quan hệ nhân quả, hiệu quả điều trị hoặc thang đo sinh học.

**Mã tham chiếu:** `06_DEMO_LAB/src/metrics.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** Mô-đun bổ sung. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-051:** Đồng nhịp · mô tả cảm nhận không suy nhân quả

```json

{"observations":[{"date":"2026-10-17","field":"work","rating":6},{"date":"2026-10-18","field":"work","rating":8},{"date":"2026-10-19","field":"sound","rating":4}]}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"summaries":[{"field":"work","count":2,"sum":14,"mean":7,"median":7},{"field":"sound","count":1,"sum":4,"mean":4,"median":4}]}}`.

**Các ca liên quan:** DEMO-051.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-15 — So sánh tiêu chí do người dùng chọn

**Công thức hoặc phép biến đổi:** Σ(trọng số × điểm tiêu chí) / 100

**Đầu vào:** Bộ tiêu chí có tổng trọng số 100 và điểm của từng phương án.

**Đầu ra được hiểu thế nào:** Điểm ưu tiên có trọng số và phần dữ liệu còn thiếu.

**Trường hợp biên:** Thiếu dữ liệu chặn xếp hạng toàn bộ; không tự chuẩn hóa lại mẫu số để làm đẹp kết quả.

**Mã tham chiếu:** `06_DEMO_LAB/src/metrics.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** Mô-đun bổ sung. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-052:** Ma trận ưu tiên do người dùng lựa chọn

```json

{"criteria":[{"id":"cost","weight":40},{"id":"time","weight":60}],"options":[{"id":"A","values":{"cost":70,"time":80}},{"id":"B","values":{"cost":90,"time":60}}]}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"ranking_allowed":true}}`.

**Các ca liên quan:** DEMO-052, DEMO-053.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## LCF-16 — Biến đổi sáu hào

**Công thức hoặc phép biến đổi:** Quẻ biến = quẻ gốc XOR mặt nạ hào động

**Đầu vào:** Sáu bit từ dưới lên; 0 là âm, 1 là dương; các hào động 1–6 không trùng.

**Đầu ra được hiểu thế nào:** Cấu trúc quẻ gốc, quẻ biến và chỉ số nhị phân.

**Trường hợp biên:** Chỉ số nhị phân không phải thứ tự Văn Vương. Demo không kèm tên quẻ hoặc lời quẻ chưa được khóa nguồn.

**Mã tham chiếu:** `06_DEMO_LAB/src/symbolic.mjs`.

**Phạm vi liên hệ kế hoạch gốc:** Mô-đun bổ sung. Không tự phê duyệt toàn bộ phương pháp gốc.

**Ví dụ DEMO-054:** Biến đổi sáu hào từ dưới lên

```json

{"lines_bottom_up":[1,0,0,0,1,0],"changing_lines":[6]}

```

**Kỳ vọng cần kiểm tra:** `{"calculation":{"changed_lines":[1,0,0,0,1,1]}}`.

**Các ca liên quan:** DEMO-054.

**Trước khi áp dụng thật:** rà soát quy tắc, nguồn, quyền sử dụng, tích hợp quyền dữ liệu và kiểm thử staging. Không dùng test số học để tuyên bố đúng số phận.



## Các adapter chưa được triển khai đầy đủ



| Mã | Phạm vi | Điều còn thiếu |
|---|---|---|
| SPEC-BAZI_PILLARS | Bát tự bốn trụ | Tiết khí, múi giờ lịch sử, ranh giới ngày và chính sách trường phái. |
| SPEC-BAZI_STRENGTH | Vượng–suy/dụng thần | Quy tắc nguồn, ví dụ độc lập và cách xử lý khác biệt trường phái. |
| SPEC-ZIWEI_PLACEMENT | Tử Vi an sao | Lịch âm, tháng nhuận, quy tắc an Mệnh, cục và hệ sao. |
| SPEC-ZIWEI_CYCLES | Đại hạn/tiểu hạn | Cách tính tuổi và chính sách chu kỳ theo trường phái. |
| SPEC-WESTERN_ASTRO | Thiên thể và hệ nhà | Giấy phép và phiên bản ephemeris; múi giờ; cấu hình hệ nhà. |
| SPEC-JYOTISH_DASHA | Jyotish và daśā | Ayanāṃśa, nakshatra và phiên bản các quy tắc daśā. |
| SPEC-QIMEN_BOARD | Kỳ Môn lập bàn | Quy tắc lập cục, tiết khí và nguồn tham chiếu. |
| SPEC-LIUYAO_RELATIONS | Lục Hào | Nguồn lấy quẻ, quy tắc lục thân, Thế–Ứng và ngày tháng. |
| SPEC-NAME_NON_LATIN | Tên ngoài Latin | Văn tự gốc, cách đọc, bảng quy đổi và người rà soát bản ngữ. |
| SPEC-NADI_LIBRARY | Kho Nadi | Bản thảo có quyền sử dụng; không giả định đã có mọi cuộc đời. |
| SPEC-IMAGE_MEASURE | Quan sát hình thái | Quyền xử lý ảnh, điều kiện chụp và hiệu chỉnh; không suy nhân cách từ hình thái. |
| SPEC-VOICE_MEASURE | Quan sát giọng nói | Quyền xử lý âm thanh, microphone và hiệu chỉnh tín hiệu; không suy đạo đức. |
| SPEC-BEHAVIOR_INSTRUMENT | Thang hành vi phù hợp | Quyền sử dụng, bản dịch, cách chấm và đánh giá phạm vi áp dụng. |
| SPEC-OUTCOME_PROBABILITY | Xác suất mục tiêu cụ thể | Mục tiêu dự báo, thời hạn, nhóm áp dụng, hiệu chỉnh và đánh giá độc lập. |
| SPEC-RLS_POSTGRES | Phân quyền cơ sở dữ liệu thực tế | Tài khoản runtime, chính sách và kiểm thử từ chối truy cập trên staging. |
| SPEC-OUTBOX_DURABLE | Idempotency bền vững | Giao dịch cơ sở dữ liệu, ràng buộc duy nhất, lease và đối soát tác vụ. |


# Thư viện 90 tình huống minh họa

Mỗi ca dùng dữ liệu tổng hợp. Lỗi được kỳ vọng là một kết quả đúng của kiểm soát, không phải lỗi phải né để tạo lời luận. Input đầy đủ nằm trong `06_DEMO_LAB/data/demo-cases.json`; output thật của lần chạy nằm trong `receipts/demo-results.json`.

| Mã | Nhóm / công cụ | Tình huống | Kỳ vọng |
|---|---|---|---|
| DEMO-001 | Bộ số / `tail80` | Đuôi 6789 · quy tắc unmapped | {"calculation":{"lookup_code":69}} |
| DEMO-002 | Bộ số / `tail80` | Đuôi 0000 · quy tắc unmapped | {"calculation":{"lookup_code":null}} |
| DEMO-003 | Bộ số / `tail80` | Đuôi 0080 · quy tắc as80 | {"calculation":{"lookup_code":80}} |
| DEMO-004 | Bộ số / `tail80` | Đuôi 0001 · quy tắc unmapped | {"calculation":{"lookup_code":1}} |
| DEMO-005 | Bộ số / `tail80` | Đuôi 9999 · quy tắc unmapped | {"calculation":{"lookup_code":79}} |
| DEMO-006 | Bộ số / `tail80` | Đuôi 6231 · quy tắc unmapped | {"calculation":{"lookup_code":71}} |
| DEMO-007 | Bộ số / `tail80` | Đuôi 1986 · quy tắc unmapped | {"calculation":{"lookup_code":66}} |
| DEMO-008 | Bộ số / `tail80` | Đuôi 3468 · quy tắc unmapped | {"calculation":{"lookup_code":28}} |
| DEMO-009 | Bộ số / `tail80` | Đầu vào ba chữ số phải bị từ chối | INVALID_SUFFIX |
| DEMO-010 | Bộ số / `pairs` | Chuỗi 1234 · giữ phần chưa biết | {"calculation":{"known":3,"total":3,"counts":{"TM":1,"HH":1,"DN":1}}} |
| DEMO-011 | Bộ số / `pairs` | Chuỗi 1819 · giữ phần chưa biết | {"calculation":{"known":3,"total":3,"counts":{"NQ":2,"DN":1}}} |
| DEMO-012 | Bộ số / `pairs` | Chuỗi 1413 · giữ phần chưa biết | {"calculation":{"known":3,"total":3,"counts":{"SK":2,"TY":1}}} |
| DEMO-013 | Bộ số / `pairs` | Chuỗi 5555 · giữ phần chưa biết | {"calculation":{"known":0,"total":3}} |
| DEMO-014 | Bộ số / `pairs` | Chuỗi 8553 · giữ phần chưa biết | {"calculation":{"known":0,"total":3}} |
| DEMO-015 | Bộ số / `pairs` | Chuỗi 0000 · giữ phần chưa biết | {"calculation":{"known":0,"total":3}} |
| DEMO-016 | Bộ số / `pairs` | Nối qua 5 chỉ để đối chiếu độ nhạy | {"calculation":{"evaluated_digits":"83","known":1}} |
| DEMO-017 | Bộ số / `digit_matrix` | Đếm tần suất chữ số thô | {"calculation":{"zero_count":4}} |
| DEMO-018 | Bộ số / `sequence` | Chuỗi đối xứng không phải số phận | {"calculation":{"palindrome":true}} |
| DEMO-019 | Bộ số / `phone` | Ký hiệu nội địa | {"canonical":"0900000001"} |
| DEMO-020 | Bộ số / `phone` | Ký hiệu quốc tế cùng chuỗi nội địa | {"canonical":"0900000001"} |
| DEMO-021 | Tên / `name` | Quy đổi có giữ nguyên tên: Đỗ An | {"calculation":{"latin":"DO AN","sum":16,"vowel_sum":7,"consonant_sum":9}} |
| DEMO-022 | Tên / `name` | Quy đổi có giữ nguyên tên: ĐỖ AN | {"calculation":{"latin":"DO AN","sum":16,"vowel_sum":7,"consonant_sum":9}} |
| DEMO-023 | Tên / `name` | Quy đổi có giữ nguyên tên: Lê Bình | {"calculation":{"latin":"LE BINH","sum":32,"vowel_sum":14,"consonant_sum":18}} |
| DEMO-024 | Tên / `name` | Quy đổi có giữ nguyên tên: Nguyễn An | {"calculation":{"latin":"NGUYEN AN","sum":38,"vowel_sum":9,"consonant_sum":29}} |
| DEMO-025 | Tên / `name` | Quy đổi có giữ nguyên tên: Demo An | {"calculation":{"latin":"DEMO AN","sum":25,"vowel_sum":12,"consonant_sum":13}} |
| DEMO-026 | Tên / `name` | Y được tính như nguyên âm theo lựa chọn | {"calculation":{"vowel_sum":8}} |
| DEMO-027 | Tên / `name` | Y không tính như nguyên âm | {"calculation":{"vowel_sum":1}} |
| DEMO-028 | Tên / `name` | Không ép chữ Hán vào bảng Latin | UNSUPPORTED_SCRIPT |
| DEMO-029 | Tên / `name` | Ký tự điều khiển bị từ chối | INVALID_NAME |
| DEMO-030 | Ngày và lịch / `birth` | Ngày nhuận hợp lệ | {"calculation":{"raw_digit_sum":15}} |
| DEMO-031 | Ngày và lịch / `birth` | Ngày không tồn tại | INVALID_INTEGER |
| DEMO-032 | Ngày và lịch / `birth` | Không đoán định dạng ngày | INVALID_DATE |
| DEMO-033 | Ngày và lịch / `birth` | Giữ số 11/22/33 khi được chọn | {"calculation":{"raw_digit_sum":24,"calculation_sum":24,"reduction":{"value":6,"root":6}}} |
| DEMO-034 | Ngày và lịch / `birth` | Đối chiếu cộng theo thành phần | {"calculation":{"raw_digit_sum":24,"calculation_sum":33,"reduction":{"value":33,"root":6}}} |
| DEMO-035 | Ngày và lịch / `cycle` | Chu kỳ biểu tượng theo năm dương lịch | {"calculation":{"personal_year":9,"personal_month":1}} |
| DEMO-036 | Ngày và lịch / `cycle` | Chu kỳ theo sinh nhật trước ngày chuyển | {"calculation":{"effective_year":2025}} |
| DEMO-037 | Ngày và lịch / `timeline` | Timeline 100 khoảng tuổi, không biến cố | {"calculation":{"age_at_as_of":26}} |
| DEMO-038 | Ngày và lịch / `timeline` | Ngày nhuận chọn mốc 01/03 | {"calculation":{"age_at_as_of":24}} |
| DEMO-039 | Ngày và lịch / `hypotheses` | Hai phương án năm sinh giữ riêng | {"calculation":{"selected":null}} |
| DEMO-040 | Múi giờ / `time` | Việt Nam · thời điểm duy nhất | {"calculation":{"state":"exact"}} |
| DEMO-041 | Múi giờ / `time` | Berlin · giờ lặp lại cần lựa chọn | {"calculation":{"state":"ambiguous"}} |
| DEMO-042 | Múi giờ / `time` | Berlin · giờ không tồn tại | {"calculation":{"state":"nonexistent"}} |
| DEMO-043 | Múi giờ / `time` | New York · giờ lặp lại | {"calculation":{"state":"ambiguous"}} |
| DEMO-044 | Múi giờ / `time` | Múi giờ chưa được cung cấp | TIMEZONE_REQUIRED |
| DEMO-045 | Quan sát / `coverage` | Coverage lấy mẫu số từ registry | {"calculation":{"numerator":1,"denominator":3}} |
| DEMO-046 | Quan sát / `coverage` | Client không được đặt lại trọng số | CLIENT_SCORES_FORBIDDEN |
| DEMO-047 | Quan sát / `actions` | Tiến độ có thời hạn và quy tắc hủy | {"calculation":{"completed":1,"due":2,"ratio":0.5}} |
| DEMO-048 | Quan sát / `actions` | Không có việc đến hạn trả null | {"calculation":{"ratio":null}} |
| DEMO-049 | Quan sát / `cashflow` | Dòng tiền số nguyên · không dự báo | {"calculation":{"net_minor":"4500000"}} |
| DEMO-050 | Quan sát / `cashflow` | Không cộng lẫn VND và USD | MIXED_CURRENCY |
| DEMO-051 | Quan sát / `resonance` | Đồng nhịp · mô tả cảm nhận không suy nhân quả | {"calculation":{"summaries":[{"field":"work","count":2,"sum":14,"mean":7,"median":7},{"field":"sound","count":1,"sum":4,"mean":4,"median":4}]}} |
| DEMO-052 | Quan sát / `preference` | Ma trận ưu tiên do người dùng lựa chọn | {"calculation":{"ranking_allowed":true}} |
| DEMO-053 | Quan sát / `preference` | Tiêu chí thiếu không tự chuẩn hóa thành 100 | {"calculation":{"ranking_allowed":false}} |
| DEMO-054 | Cấu trúc biểu tượng / `hexagram` | Biến đổi sáu hào từ dưới lên | {"calculation":{"changed_lines":[1,0,0,0,1,1]}} |
| DEMO-055 | Phạm vi nghiên cứu / `blocked` | Adapter giữ chỗ có điều kiện: bazi.full | {"status":"METHOD_NOT_RELEASED"} |
| DEMO-056 | Phạm vi nghiên cứu / `blocked` | Adapter giữ chỗ có điều kiện: ziwei.full | {"status":"METHOD_NOT_RELEASED"} |
| DEMO-057 | Phạm vi nghiên cứu / `blocked` | Adapter giữ chỗ có điều kiện: nadi.record_lookup | {"status":"METHOD_NOT_RELEASED"} |
| DEMO-058 | Phạm vi nghiên cứu / `blocked` | Chặn loại suy luận vượt phạm vi: face.personality | {"status":"POLICY_BLOCKED"} |
| DEMO-059 | Phạm vi nghiên cứu / `blocked` | Chặn loại suy luận vượt phạm vi: medical_risk_from_palm | {"status":"POLICY_BLOCKED"} |
| DEMO-060 | Quyền và vận hành / `authorization` | Quyền đúng phạm vi | {"allowed":true} |
| DEMO-061 | Quyền và vận hành / `authorization` | Khác chủ thể bị chặn | {"allowed":false} |
| DEMO-062 | Quyền và vận hành / `authorization` | Quyền đã thu hồi bị chặn | {"allowed":false} |
| DEMO-063 | Quyền và vận hành / `authorization` | Khác mục đích bị chặn | {"allowed":false} |
| DEMO-064 | Quyền và vận hành / `authorization` | Revision cũ bị chặn | {"allowed":false} |
| DEMO-065 | Quyền và vận hành / `authorization` | Người chưa đăng nhập bị chặn | {"allowed":false} |
| DEMO-066 | Quyền và vận hành / `claim` | Biểu tượng không được có xác suất | PROBABILITY_NOT_ALLOWED |
| DEMO-067 | Quyền và vận hành / `claim` | Model ID giả không mở quyền dự báo | MODEL_NOT_APPROVED |
| DEMO-068 | Quyền và vận hành / `optimistic` | Cập nhật đúng phiên bản | {"version":5} |
| DEMO-069 | Quyền và vận hành / `optimistic` | Cập nhật từ phiên bản cũ bị chặn | VERSION_CONFLICT |
| DEMO-070 | Quyền và vận hành / `transition` | Thanh toán có trạng thái riêng | {"next":"paid"} |
| DEMO-071 | Quyền và vận hành / `transition` | Không đi từ nháp thẳng tới hoàn tất | INVALID_STATE_TRANSITION |
| DEMO-072 | Quyền và vận hành / `transition` | Yêu cầu xóa chuyển sang hạn chế truy cập | {"next":"restricted"} |
| DEMO-073 | Báo cáo / `report` | Level 1 · bốn lớp và phần còn thiếu | {"level":1,"production_ready":false} |
| DEMO-074 | Báo cáo / `report` | Level 2 · bốn lớp và phần còn thiếu | {"level":2,"production_ready":false} |
| DEMO-075 | Báo cáo / `report` | Level 3 · bốn lớp và phần còn thiếu | {"level":3,"production_ready":false} |
| DEMO-076 | Báo cáo / `report` | Level 4 · bốn lớp và phần còn thiếu | {"level":4,"production_ready":false} |
| DEMO-077 | Báo cáo / `report` | Level 5 · bốn lớp và phần còn thiếu | {"level":5,"production_ready":false} |
| DEMO-078 | Báo cáo / `report` | Level 6 · bốn lớp và phần còn thiếu | {"level":6,"production_ready":false} |
| DEMO-079 | Báo cáo / `report` | Level 7 · bốn lớp và phần còn thiếu | {"level":7,"production_ready":false} |
| DEMO-080 | Báo cáo / `report` | Level 8 · bốn lớp và phần còn thiếu | {"level":8,"production_ready":false} |
| DEMO-081 | Báo cáo / `report` | Level 9 · bốn lớp và phần còn thiếu | {"level":9,"production_ready":false} |
| DEMO-082 | Luồng hồ sơ hoàn chỉnh / `profile_pipeline` | Hồ sơ xuyên suốt: đủ dữ liệu nền | {"state":"DRAFT_REFERENCE_ONLY","level":1} |
| DEMO-083 | Luồng hồ sơ hoàn chỉnh / `profile_pipeline` | Hồ sơ thiếu dữ liệu: không điền giờ sinh giả | {"state":"PARTIAL_REFERENCE","score":null} |
| DEMO-084 | Luồng hồ sơ hoàn chỉnh / `profile_pipeline` | Hồ sơ có hai ngày sinh: cần lựa chọn | {"state":"NEEDS_INPUT_CHOICE","probability":null} |
| DEMO-085 | Điều phối và tính gia tăng / `dag` | DAG: chia các đợt tính độc lập | {"status":"REFERENCE_PLAN_ONLY"} |
| DEMO-086 | Điều phối và tính gia tăng / `dag` | DAG: chặn chu trình | DAG_CYCLE |
| DEMO-087 | Điều phối và tính gia tăng / `dag` | DAG: thiếu phụ thuộc không tự bỏ qua | MISSING_DEPENDENCY |
| DEMO-088 | Điều phối và tính gia tăng / `impact` | Impact: đổi ngày chỉ chạy các nút phụ thuộc | {"impacted":["birth","cycle","report"],"unchanged":["profile","name"]} |
| DEMO-089 | Điều phối và tính gia tăng / `cache_key` | Cache: khóa theo tenant/chủ thể/mục đích | {"scope":"tenant_subject_purpose_version"} |
| DEMO-090 | Điều phối và tính gia tăng / `cache_key` | Cache: thiếu chủ thể phải từ chối | INVALID_CACHE_CONTEXT |


# DEMO-082 — Hồ sơ tổng hợp A

**Trạng thái:** DRAFT_REFERENCE_ONLY. **Dữ liệu:** tổng hợp, không phải người thật.



## Dữ liệu được sử dụng

Hồ sơ tổng hợp A là hồ sơ tổng hợp dùng để kiểm tra luồng. Mục tiêu do người dùng lựa chọn: Hoàn thành bản mô tả một sản phẩm. Không nhận diện người thật hoặc suy đoán giới tính.



## Kết quả tính và cách đọc

Theo bảng Latin demo, tổng tên là 25. Tổng chữ số ngày sinh là 31; chuỗi rút gọn: 31 → 4. Những kết quả này là phép quy đổi theo cấu hình, không đo trí tuệ, đạo đức, sức khỏe hoặc giá trị con người.



## Thời gian và phạm vi

Chu kỳ số theo năm dương lịch đang cho mã 4 ở năm 2026. Mã được trình bày riêng với lịch hành động, không biến thành năm thành công hoặc tai họa. Khung tuổi chỉ là các khoảng lịch không kèm biến cố.



## Một bước thực tế trong 30 ngày

Tuần 1: viết đầu ra cụ thể của mục tiêu “Hoàn thành bản mô tả một sản phẩm”. Tuần 2: chọn lịch thực hiện vừa sức. Tuần 3: ghi việc đã làm và điều cản trở. Tuần 4: xem lại kết quả theo tiêu chí tự chọn; sửa kế hoạch thay vì cố làm cho trải nghiệm khớp một lời luận.



## Phần chưa có

Không thiếu trường bắt buộc của phạm vi demo.

## Chú ý

Kết quả này không phải bản Level 1 thương mại đã được rà soát. Không có xác suất, điểm sức khỏe hoặc kết luận nhân cách.


# DEMO-083 — Hồ sơ tổng hợp B

**Trạng thái:** PARTIAL_REFERENCE. **Dữ liệu:** tổng hợp, không phải người thật.



## Dữ liệu được sử dụng

Hồ sơ tổng hợp B là hồ sơ tổng hợp dùng để kiểm tra luồng. Mục tiêu do người dùng lựa chọn: Lập lịch học một kỹ năng. Không nhận diện người thật hoặc suy đoán giới tính.



## Kết quả tính và cách đọc

Theo bảng Latin demo, tổng tên là 43. Tổng chữ số ngày sinh là 13; chuỗi rút gọn: 13 → 4. Những kết quả này là phép quy đổi theo cấu hình, không đo trí tuệ, đạo đức, sức khỏe hoặc giá trị con người.



## Thời gian và phạm vi

Chu kỳ số theo năm dương lịch đang cho mã 2 ở năm 2026. Mã được trình bày riêng với lịch hành động, không biến thành năm thành công hoặc tai họa. Khung tuổi chỉ là các khoảng lịch không kèm biến cố.



## Một bước thực tế trong 30 ngày

Tuần 1: viết đầu ra cụ thể của mục tiêu “Lập lịch học một kỹ năng”. Tuần 2: chọn lịch thực hiện vừa sức. Tuần 3: ghi việc đã làm và điều cản trở. Tuần 4: xem lại kết quả theo tiêu chí tự chọn; sửa kế hoạch thay vì cố làm cho trải nghiệm khớp một lời luận.



## Phần chưa có

birth_time

## Chú ý

Kết quả này không phải bản Level 1 thương mại đã được rà soát. Không có xác suất, điểm sức khỏe hoặc kết luận nhân cách.


# DEMO-084 — Hồ sơ tổng hợp C

**Trạng thái:** NEEDS_INPUT_CHOICE. **Dữ liệu:** tổng hợp, không phải người thật.



## Dữ liệu được sử dụng

Hồ sơ tổng hợp C là hồ sơ tổng hợp dùng để kiểm tra luồng. Mục tiêu do người dùng lựa chọn: Ghi lại dữ liệu gia đình. Không nhận diện người thật hoặc suy đoán giới tính.



## Kết quả tính và cách đọc

Theo bảng Latin demo, tổng tên là 43. Ngày sinh chưa được khóa; không điền một ngày giả. Những kết quả này là phép quy đổi theo cấu hình, không đo trí tuệ, đạo đức, sức khỏe hoặc giá trị con người.



## Thời gian và phạm vi

Chưa tạo chu kỳ hoặc dòng thời gian cá nhân vì ngày sinh thiếu hoặc còn nhiều phương án.



## Một bước thực tế trong 30 ngày

Tuần 1: viết đầu ra cụ thể của mục tiêu “Ghi lại dữ liệu gia đình”. Tuần 2: chọn lịch thực hiện vừa sức. Tuần 3: ghi việc đã làm và điều cản trở. Tuần 4: xem lại kết quả theo tiêu chí tự chọn; sửa kế hoạch thay vì cố làm cho trải nghiệm khớp một lời luận.



## Phần chưa có

selected_birth_hypothesis

## Chú ý

Kết quả này không phải bản Level 1 thương mại đã được rà soát. Không có xác suất, điểm sức khỏe hoặc kết luận nhân cách.


# Nguồn tham khảo và phạm vi đã tiếp cận



Những nguồn có nhãn kế thừa chưa được xem là đã đọc lại toàn văn trong V2. Nguồn bên thứ ba cung cấp căn cứ kỹ thuật hoặc nội dung nghiên cứu, không xác nhận toàn bộ Huyền Nhân Học.



## N01 — W3C WCAG 2.2

Tiêu chuẩn accessibility; chỉ mục tiêu thiết kế, chưa chứng nhận AA

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://www.w3.org/TR/WCAG22/



## N02 — PostgreSQL Row Security

RLS; role và owner bypass cần kiểm thử riêng

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://www.postgresql.org/docs/current/ddl-rowsecurity.html



## N03 — Cloudflare Queues delivery

At-least-once; idempotency

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://developers.cloudflare.com/queues/reference/delivery-guarantees/



## N04 — OpenAPI 3.1.1

Phiên bản hợp đồng được chọn; không khẳng định mới nhất

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://spec.openapis.org/oas/v3.1.1.html



## N05 — RFC 9457 Problem Details

Định dạng lỗi HTTP

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://www.rfc-editor.org/rfc/rfc9457.html



## N06 — RFC 8785 JCS

Tham chiếu canonicalization; demo chỉ hỗ trợ tập con riêng

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://www.rfc-editor.org/rfc/rfc8785.html



## N07 — Unicode normalization

Giữ nguyên tên và tạo derivative NFC

Trạng thái: OFFICIAL_REFERENCE_BASELINE_CARRIED_FORWARD. Ngày ghi nhận: 2026-10-20.

https://unicode.org/reports/tr15/



## N08 — IANA time zone database

Lịch sử múi giờ và pin version

Trạng thái: OFFICIAL_REFERENCE_BASELINE_CARRIED_FORWARD. Ngày ghi nhận: 2026-10-20.

https://www.iana.org/time-zones



## N09 — OWASP object authorization

Quyền từng đối tượng

Trạng thái: OFFICIAL_REFERENCE_BASELINE_CARRIED_FORWARD. Ngày ghi nhận: 2026-10-20.

https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/



## N10 — JSON Schema 2020-12

Schema cấu trúc; không thay business authorization

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://json-schema.org/draft/2020-12



## N11 — Luật 91/2025/QH15

Metadata văn bản; áp dụng cần counsel

Trạng thái: CURRENT_PUBLIC_METADATA. Ngày ghi nhận: 2026-10-20.

https://congbao.chinhphu.vn/van-ban/luat-so-91-2025-qh15-45578/57730.htm



## N12 — Luật 134/2025/QH15

Metadata văn bản; áp dụng cần counsel

Trạng thái: CURRENT_PUBLIC_METADATA. Ngày ghi nhận: 2026-10-20.

https://congbao.chinhphu.vn/van-ban/luat-so-134-2025-qh15-468694/61695.htm



## N13 — Luật 122/2025/QH15

Metadata văn bản; áp dụng cần counsel

Trạng thái: CURRENT_PUBLIC_METADATA. Ngày ghi nhận: 2026-10-20.

https://congbao.chinhphu.vn/van-ban/luat-so-122-2025-qh15-468683/61714.htm



## N14 — Nghị định hướng dẫn AI 142/2026

Nguồn thông tin Chính phủ; chưa thay đọc điều khoản

Trạng thái: CURRENT_PUBLIC_METADATA. Ngày ghi nhận: 2026-10-20.

https://media.chinhphu.vn/ban-hanh-nghi-dinh-quy-dinh-chi-tiet-mot-so-dieu-va-bien-phap-thi-hanh-luat-tri-tue-nhan-tao-102260508162952667.htm



## N15 — EU AI Act FAQs

Phân loại chức năng và hành vi bị cấm

Trạng thái: CURRENT_PUBLIC_METADATA. Ngày ghi nhận: 2026-10-20.

https://digital-strategy.ec.europa.eu/en/faqs/navigating-ai-act



## N16 — Life Code public home

Nội dung public được công cụ truy xuất; không receipt runtime SHA

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://lifecode.iai.one/



## N17 — GitHub main pinned

Mã nguồn remote được đọc

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://github.com/tranhatam-collab/Life-Code-OS/tree/99b402764437f81859fa0cd3a3af860125f7bd52



## N18 — GitHub audit pinned

Baseline audit; không chứng nhận production

Trạng thái: CURRENT_CONTENT_READ. Ngày ghi nhận: 2026-10-20.

https://github.com/tranhatam-collab/Life-Code-OS/tree/336ef35a8386a744c6de18a7f7c6e268e89e6dac


